package com.renan.f0122305.labrador;

import com.google.android.gms.maps.model.LatLng;

import java.util.HashMap;

/**
 * Created by renan on 6/28/17.
 */

final class Constants {

    private Constants(){}

    static final HashMap<String,LatLng> BAY_AREA_LANDMARKS = new HashMap<>();

    static {

        BAY_AREA_LANDMARKS.put("esquina",new LatLng(-23.6287256,-46.64537672));

        BAY_AREA_LANDMARKS.put("igreja",new LatLng(-23.62741583,-46.64299492));

        BAY_AREA_LANDMARKS.put("esquina_rio_branco",new LatLng(-23.53071494,-46.64647374));

        BAY_AREA_LANDMARKS.put("porto",new LatLng(-23.53147974,-46.64628063));

        //-23.53147974,-46.64628063
    }

}
