package com.renan.f0122305.labrador;

import android.Manifest;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.provider.SyncStateContract;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class MainActivity extends AppCompatActivity  {
    TextView tvLatitude;
    TextView tvLongitude;
    LocationManager locationManager;
    final int MY_REQUEST_CODE = 100;
    Location location;
    GeofencingClient mGeofencingClient;
    List<Geofence> mGeofenceList;
    PendingIntent mGeofencePendingIntent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        mGeofenceList = new ArrayList<Geofence>();

        mGeofencePendingIntent = null;

        popularGeofenceList();

        mGeofencingClient = LocationServices.getGeofencingClient(this);

        tvLatitude = (TextView)findViewById(R.id.tv_latitude);
        tvLongitude = (TextView)findViewById(R.id.tv_longitude);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {


                } else {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_REQUEST_CODE);
                }
            }
        }else{
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 5, locationListener);
            location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            //tvLatitude.setText(String.valueOf(location.getLatitude()));
            //tvLongitude.setText(String.valueOf(location.getLongitude()));
        }


    }

    private void popularGeofenceList() {

        for(Map.Entry<String,LatLng> entry : Constants.BAY_AREA_LANDMARKS.entrySet()){

            mGeofenceList.add(new Geofence.Builder()
                        .setRequestId(entry.getKey())
                        .setCircularRegion(entry.getValue().latitude,entry.getValue().longitude,10)
                        .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER|Geofence.GEOFENCE_TRANSITION_EXIT).build());
        }


    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case MY_REQUEST_CODE:
                if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    Log.i("Tag:","Aprovado");
                }
        }


    }

    LocationListener locationListener = new LocationListener(){
        @Override
        public void onLocationChanged(Location location) {

            tvLatitude.setText(String.valueOf(location.getLatitude()));
            tvLongitude.setText(String.valueOf(location.getLongitude()));
        }

        @Override
        public void onStatusChanged(String s, int i, Bundle bundle) {

        }

        @Override
        public void onProviderEnabled(String s) {

        }

        @Override
        public void onProviderDisabled(String s) {

        }
    };



}
