package com.renan.f0122305.labrador;

import android.app.IntentService;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;

/**
 * Created by f0122305 on 27/06/2017.
 */

public class GeofenceTransitionsIntentService extends IntentService {


    public GeofenceTransitionsIntentService(String name) {
        super(name);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

    }
}
